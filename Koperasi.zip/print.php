<?php
include 'inc/koneksi.php';
if (@$_GET['page']=='pendapatan'){
		include 'inc/printpendapatan.php';
}
?>