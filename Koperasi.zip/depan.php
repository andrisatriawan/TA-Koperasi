<section class="depan">
	<div class="container text-center">
		<div class="row">
			<div class="col-md-12">
				<h1>Selamat Datang <?php echo $data['nama']; ?> </h1>
			</div>
		</div>
	</div>
</section>